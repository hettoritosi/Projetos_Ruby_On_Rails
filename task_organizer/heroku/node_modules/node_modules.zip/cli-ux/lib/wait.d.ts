declare const _default: (ms?: number) => Promise<{}>;
export default _default;
