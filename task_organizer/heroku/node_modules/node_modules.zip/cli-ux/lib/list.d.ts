export declare type IListItem = [string, string | undefined];
export declare type IList = IListItem[];
export declare function renderList(items: IListItem[]): string;
