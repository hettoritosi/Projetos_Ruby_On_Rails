declare module 'date-fns/get_day' {
  import {getDay} from 'date-fns'
  export = getDay
}
