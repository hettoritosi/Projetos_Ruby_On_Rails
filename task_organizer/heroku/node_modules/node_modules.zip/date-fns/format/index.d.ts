declare module 'date-fns/format' {
  import {format} from 'date-fns'
  export = format
}
