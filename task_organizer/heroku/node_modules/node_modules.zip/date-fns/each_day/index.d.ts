declare module 'date-fns/each_day' {
  import {eachDay} from 'date-fns'
  export = eachDay
}
