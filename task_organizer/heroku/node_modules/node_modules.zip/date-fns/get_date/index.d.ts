declare module 'date-fns/get_date' {
  import {getDate} from 'date-fns'
  export = getDate
}
