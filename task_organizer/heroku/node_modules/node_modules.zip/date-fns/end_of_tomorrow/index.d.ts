declare module 'date-fns/end_of_tomorrow' {
  import {endOfTomorrow} from 'date-fns'
  export = endOfTomorrow
}
