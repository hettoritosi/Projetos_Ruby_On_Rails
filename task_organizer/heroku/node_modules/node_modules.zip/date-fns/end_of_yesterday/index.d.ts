declare module 'date-fns/end_of_yesterday' {
  import {endOfYesterday} from 'date-fns'
  export = endOfYesterday
}
