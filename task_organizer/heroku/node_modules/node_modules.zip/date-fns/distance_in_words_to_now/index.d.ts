declare module 'date-fns/distance_in_words_to_now' {
  import {distanceInWordsToNow} from 'date-fns'
  export = distanceInWordsToNow
}
