'use strict';

module.exports = (...arguments_) => {
	return [...new Set([].concat(...arguments_))];
};
