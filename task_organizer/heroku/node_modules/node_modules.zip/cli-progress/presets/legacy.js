// cli-progress legacy style as of 1.x
module.exports = {
    format: 'progress [{bar}] {percentage}% | ETA: {eta}s | {value}/{total}',
    barCompleteChar: '=',
    barIncompleteChar: '-'
};